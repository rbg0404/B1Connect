import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Building2, Search, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { useToast } from "@/hooks/use-toast";
import SharedLayout from "@/components/shared-layout";
import type { BranchMaster, ApiResponse } from "@shared/schema";

export default function Branches() {
  const [selectedBranch, setSelectedBranch] = useState<BranchMaster | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  // Fetch branches
  const { data: branchesData, isLoading: branchesLoading, error: branchesError } = useQuery<ApiResponse<BranchMaster[]>>({
    queryKey: ["/api/branches"]
  });

  const branches = (branchesData as any)?.data || [];
  
  // Filter branches based on search term
  const filteredBranches = branches.filter((branch: BranchMaster) =>
    branch.Name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    branch.Code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (inactive: string) => {
    return inactive === "tNO" ? "text-green-600" : "text-red-600";
  };

  const getStatusName = (inactive: string) => {
    return inactive === "tNO" ? "Active" : "Inactive";
  };

  const getMainBranchColor = (mainBranch: string) => {
    return mainBranch === "tYES" ? "text-blue-600" : "text-gray-600";
  };

  const getMainBranchName = (mainBranch: string) => {
    return mainBranch === "tYES" ? "Main Branch" : "Branch";
  };

  const handleViewBranch = (branch: BranchMaster) => {
    setSelectedBranch(branch);
  };

  return (
    <SharedLayout currentPage="/branches">
      <div className="flex h-screen">
        {/* Left Panel - Branches List */}
        <div className="w-1/2 border-r border-border overflow-hidden flex flex-col">
          <div className="p-6 border-b border-border">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <Building2 className="h-5 w-5" />
                Branch Master
              </h2>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by branch name or code..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
                data-testid="input-search-branches"
              />
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto">
            {branchesLoading ? (
              <div className="flex items-center justify-center py-8">
                <LoadingSpinner className="h-8 w-8" />
              </div>
            ) : branchesError ? (
              <div className="p-6 text-center text-muted-foreground">
                <p className="text-red-600">Failed to load branches</p>
                <p className="text-sm mt-2">Please check your connection and try again</p>
              </div>
            ) : filteredBranches.length === 0 ? (
              <div className="p-6 text-center text-muted-foreground">
                {searchTerm ? "No branches found matching your search" : "No branches found"}
              </div>
            ) : (
              <div className="space-y-2 p-4">
                {filteredBranches.map((branch: BranchMaster) => (
                  <Card 
                    key={branch.Code} 
                    className={`cursor-pointer transition-colors hover:bg-muted/50 ${
                      selectedBranch?.Code === branch.Code ? 'bg-muted border-primary' : ''
                    }`}
                    onClick={() => setSelectedBranch(branch)}
                    data-testid={`card-branch-${branch.Code}`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="font-mono text-sm font-medium">{branch.Code}</div>
                        <Badge className={branch.MainBranch === 'tYES' ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300" : "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"}>
                          {getMainBranchName(branch.MainBranch || 'tNO')}
                        </Badge>
                      </div>
                      <div className="font-medium text-foreground mb-1">{branch.Name}</div>
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${branch.Inactive === 'tNO' ? 'bg-green-500' : 'bg-red-500'}`}></div>
                          <span className={getStatusColor(branch.Inactive || 'tNO')}>
                            {getStatusName(branch.Inactive || 'tNO')}
                          </span>
                        </div>
                        <div className="font-mono text-xs text-muted-foreground">
                          {branch.Description ? branch.Description.substring(0, 20) + '...' : 'N/A'}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
          
          <div className="p-4 border-t border-border text-sm text-muted-foreground">
            Showing {filteredBranches.length} of {branches.length} branches
          </div>
        </div>

        {/* Right Panel - Branch Details */}
        <div className="w-1/2 overflow-hidden flex flex-col">
          {selectedBranch ? (
            <>
              <div className="p-6 border-b border-border">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold">{selectedBranch.Name}</h3>
                    <p className="text-sm text-muted-foreground font-mono">{selectedBranch.Code}</p>
                  </div>
                  <Button 
                    size="sm" 
                    data-testid={`button-view-detail-${selectedBranch.Code}`}
                    onClick={() => {/* Navigate to individual detail view */}}
                  >
                    <Eye className="h-4 w-4 mr-1" />
                    View Details
                  </Button>
                </div>
              </div>
              
              <div className="flex-1 overflow-y-auto p-6">
                <div className="space-y-6">
                  {/* Basic Information */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Basic Information</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium text-muted-foreground">Branch Code</label>
                          <p className="font-mono text-sm">{selectedBranch.Code}</p>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-muted-foreground">Branch Name</label>
                          <p className="text-sm">{selectedBranch.Name}</p>
                        </div>
                        <div className="col-span-2">
                          <label className="text-sm font-medium text-muted-foreground">Description</label>
                          <p className="text-sm">{selectedBranch.Description || 'N/A'}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Branch Information */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Branch Information</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium text-muted-foreground">Branch Type</label>
                          <div className="flex items-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${selectedBranch.MainBranch === 'tYES' ? 'bg-blue-500' : 'bg-green-500'}`}></div>
                            <span className={`text-sm ${getMainBranchColor(selectedBranch.MainBranch || 'tNO')}`}>
                              {getMainBranchName(selectedBranch.MainBranch || 'tNO')}
                            </span>
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-muted-foreground">Status</label>
                          <div className="flex items-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${selectedBranch.Inactive === 'tNO' ? 'bg-green-500' : 'bg-red-500'}`}></div>
                            <span className={`text-sm ${getStatusColor(selectedBranch.Inactive || 'tNO')}`}>
                              {getStatusName(selectedBranch.Inactive || 'tNO')}
                            </span>
                          </div>
                        </div>
                        {selectedBranch.Address && (
                          <div className="col-span-2">
                            <label className="text-sm font-medium text-muted-foreground">Address</label>
                            <p className="text-sm">{selectedBranch.Address}</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground">
              <div className="text-center">
                <Building2 className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>Select a branch to view details</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </SharedLayout>
  );
}