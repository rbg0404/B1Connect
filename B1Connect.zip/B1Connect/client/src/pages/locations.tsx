import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MapPin, Search, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { useToast } from "@/hooks/use-toast";
import SharedLayout from "@/components/shared-layout";
import type { LocationMaster, ApiResponse } from "@shared/schema";

export default function Locations() {
  const [selectedLocation, setSelectedLocation] = useState<LocationMaster | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  // Fetch locations
  const { data: locationsData, isLoading: locationsLoading, error: locationsError } = useQuery<ApiResponse<LocationMaster[]>>({
    queryKey: ["/api/locations"]
  });

  const locations = (locationsData as any)?.data || [];
  
  // Filter locations based on search term
  const filteredLocations = locations.filter((location: LocationMaster) =>
    location.Name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    location.Code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (inactive: string) => {
    return inactive === "tNO" ? "text-green-600" : "text-red-600";
  };

  const getStatusName = (inactive: string) => {
    return inactive === "tNO" ? "Active" : "Inactive";
  };

  const getLockColor = (locked: string) => {
    return locked === "tNO" ? "text-green-600" : "text-yellow-600";
  };

  const getLockName = (locked: string) => {
    return locked === "tNO" ? "Unlocked" : "Locked";
  };

  const handleViewLocation = (location: LocationMaster) => {
    setSelectedLocation(location);
  };

  return (
    <SharedLayout currentPage="/locations">
      <div className="flex h-screen">
        {/* Left Panel - Locations List */}
        <div className="w-1/2 border-r border-border overflow-hidden flex flex-col">
          <div className="p-6 border-b border-border">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Location Master
              </h2>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by location name or code..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
                data-testid="input-search-locations"
              />
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto">
            {locationsLoading ? (
              <div className="flex items-center justify-center py-8">
                <LoadingSpinner className="h-8 w-8" />
              </div>
            ) : locationsError ? (
              <div className="p-6 text-center text-muted-foreground">
                <p className="text-red-600">Failed to load locations</p>
                <p className="text-sm mt-2">Please check your connection and try again</p>
              </div>
            ) : filteredLocations.length === 0 ? (
              <div className="p-6 text-center text-muted-foreground">
                {searchTerm ? "No locations found matching your search" : "No locations found"}
              </div>
            ) : (
              <div className="space-y-2 p-4">
                {filteredLocations.map((location: LocationMaster) => (
                  <Card 
                    key={location.Code} 
                    className={`cursor-pointer transition-colors hover:bg-muted/50 ${
                      selectedLocation?.Code === location.Code ? 'bg-muted border-primary' : ''
                    }`}
                    onClick={() => setSelectedLocation(location)}
                    data-testid={`card-location-${location.Code}`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="font-mono text-sm font-medium">{location.Code}</div>
                        <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300">
                          Location
                        </Badge>
                      </div>
                      <div className="font-medium text-foreground mb-1">{location.Name}</div>
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${location.Inactive === 'tNO' ? 'bg-green-500' : 'bg-red-500'}`}></div>
                          <span className={getStatusColor(location.Inactive || 'tNO')}>
                            {getStatusName(location.Inactive || 'tNO')}
                          </span>
                        </div>
                        <div className="font-mono text-xs text-muted-foreground">
                          {location.WarehouseCode || 'N/A'}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
          
          <div className="p-4 border-t border-border text-sm text-muted-foreground">
            Showing {filteredLocations.length} of {locations.length} locations
          </div>
        </div>

        {/* Right Panel - Location Details */}
        <div className="w-1/2 overflow-hidden flex flex-col">
          {selectedLocation ? (
            <>
              <div className="p-6 border-b border-border">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold">{selectedLocation.Name}</h3>
                    <p className="text-sm text-muted-foreground font-mono">{selectedLocation.Code}</p>
                  </div>
                  <Button 
                    size="sm" 
                    data-testid={`button-view-detail-${selectedLocation.Code}`}
                    onClick={() => {/* Navigate to individual detail view */}}
                  >
                    <Eye className="h-4 w-4 mr-1" />
                    View Details
                  </Button>
                </div>
              </div>
              
              <div className="flex-1 overflow-y-auto p-6">
                <div className="space-y-6">
                  {/* Basic Information */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Basic Information</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium text-muted-foreground">Location Code</label>
                          <p className="font-mono text-sm">{selectedLocation.Code}</p>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-muted-foreground">Location Name</label>
                          <p className="text-sm">{selectedLocation.Name}</p>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-muted-foreground">Warehouse Code</label>
                          <p className="font-mono text-sm">{selectedLocation.WarehouseCode || 'N/A'}</p>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-muted-foreground">Location Type</label>
                          <p className="text-sm">{selectedLocation.LocationType || 'N/A'}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Status Information */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Status Information</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium text-muted-foreground">Status</label>
                          <div className="flex items-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${selectedLocation.Inactive === 'tNO' ? 'bg-green-500' : 'bg-red-500'}`}></div>
                            <span className={`text-sm ${getStatusColor(selectedLocation.Inactive || 'tNO')}`}>
                              {getStatusName(selectedLocation.Inactive || 'tNO')}
                            </span>
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-muted-foreground">Lock Status</label>
                          <div className="flex items-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${selectedLocation.Locked === 'tNO' ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                            <span className={`text-sm ${getLockColor(selectedLocation.Locked || 'tNO')}`}>
                              {getLockName(selectedLocation.Locked || 'tNO')}
                            </span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground">
              <div className="text-center">
                <MapPin className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>Select a location to view details</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </SharedLayout>
  );
}