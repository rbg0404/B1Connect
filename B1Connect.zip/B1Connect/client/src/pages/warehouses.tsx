import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Warehouse, Search, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { useToast } from "@/hooks/use-toast";
import SharedLayout from "@/components/shared-layout";
import type { WarehouseMaster, ApiResponse } from "@shared/schema";

export default function Warehouses() {
  const [selectedWarehouse, setSelectedWarehouse] = useState<WarehouseMaster | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  // Fetch warehouses
  const { data: warehousesData, isLoading: warehousesLoading, error: warehousesError } = useQuery<ApiResponse<WarehouseMaster[]>>({
    queryKey: ["/api/warehouses"]
  });

  const warehouses = (warehousesData as any)?.data || [];
  
  // Filter warehouses based on search term
  const filteredWarehouses = warehouses.filter((warehouse: WarehouseMaster) =>
    warehouse.WarehouseName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    warehouse.WarehouseCode.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (inactive: string) => {
    return inactive === "tNO" ? "text-green-600" : "text-red-600";
  };

  const getStatusName = (inactive: string) => {
    return inactive === "tNO" ? "Active" : "Inactive";
  };

  const getDropShipColor = (dropShip: string) => {
    return dropShip === "tYES" ? "text-blue-600" : "text-gray-600";
  };

  const getDropShipName = (dropShip: string) => {
    return dropShip === "tYES" ? "Drop Ship" : "Regular";
  };

  const getNettableColor = (nettable: string) => {
    return nettable === "tYES" ? "text-green-600" : "text-yellow-600";
  };

  const getNettableName = (nettable: string) => {
    return nettable === "tYES" ? "Nettable" : "Not Nettable";
  };

  const handleViewWarehouse = (warehouse: WarehouseMaster) => {
    setSelectedWarehouse(warehouse);
  };

  return (
    <SharedLayout currentPage="/warehouses">
      <div className="flex h-screen">
        {/* Left Panel - Warehouses List */}
        <div className="w-1/2 border-r border-border overflow-hidden flex flex-col">
          <div className="p-6 border-b border-border">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <Warehouse className="h-5 w-5" />
                Warehouse Master
              </h2>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by warehouse name or code..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
                data-testid="input-search-warehouses"
              />
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto">
            {warehousesLoading ? (
              <div className="flex items-center justify-center py-8">
                <LoadingSpinner className="h-8 w-8" />
              </div>
            ) : warehousesError ? (
              <div className="p-6 text-center text-muted-foreground">
                <p className="text-red-600">Failed to load warehouses</p>
                <p className="text-sm mt-2">Please check your connection and try again</p>
              </div>
            ) : filteredWarehouses.length === 0 ? (
              <div className="p-6 text-center text-muted-foreground">
                {searchTerm ? "No warehouses found matching your search" : "No warehouses found"}
              </div>
            ) : (
              <div className="space-y-2 p-4">
                {filteredWarehouses.map((warehouse: WarehouseMaster) => (
                  <Card 
                    key={warehouse.WarehouseCode} 
                    className={`cursor-pointer transition-colors hover:bg-muted/50 ${
                      selectedWarehouse?.WarehouseCode === warehouse.WarehouseCode ? 'bg-muted border-primary' : ''
                    }`}
                    onClick={() => setSelectedWarehouse(warehouse)}
                    data-testid={`card-warehouse-${warehouse.WarehouseCode}`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="font-mono text-sm font-medium">{warehouse.WarehouseCode}</div>
                        <Badge className={warehouse.DropShip === 'tYES' ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300" : "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"}>
                          {getDropShipName(warehouse.DropShip || 'tNO')}
                        </Badge>
                      </div>
                      <div className="font-medium text-foreground mb-1">{warehouse.WarehouseName}</div>
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${warehouse.Inactive === 'tNO' ? 'bg-green-500' : 'bg-red-500'}`}></div>
                          <span className={getStatusColor(warehouse.Inactive || 'tNO')}>
                            {getStatusName(warehouse.Inactive || 'tNO')}
                          </span>
                        </div>
                        <div className="font-mono text-xs text-muted-foreground">
                          {warehouse.Location ? warehouse.Location.substring(0, 15) + '...' : 'N/A'}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
          
          <div className="p-4 border-t border-border text-sm text-muted-foreground">
            Showing {filteredWarehouses.length} of {warehouses.length} warehouses
          </div>
        </div>

        {/* Right Panel - Warehouse Details */}
        <div className="w-1/2 overflow-hidden flex flex-col">
          {selectedWarehouse ? (
            <>
              <div className="p-6 border-b border-border">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold">{selectedWarehouse.WarehouseName}</h3>
                    <p className="text-sm text-muted-foreground font-mono">{selectedWarehouse.WarehouseCode}</p>
                  </div>
                  <Button 
                    size="sm" 
                    data-testid={`button-view-detail-${selectedWarehouse.WarehouseCode}`}
                    onClick={() => {/* Navigate to individual detail view */}}
                  >
                    <Eye className="h-4 w-4 mr-1" />
                    View Details
                  </Button>
                </div>
              </div>
              
              <div className="flex-1 overflow-y-auto p-6">
                <div className="space-y-6">
                  {/* Basic Information */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Basic Information</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium text-muted-foreground">Warehouse Code</label>
                          <p className="font-mono text-sm">{selectedWarehouse.WarehouseCode}</p>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-muted-foreground">Warehouse Name</label>
                          <p className="text-sm">{selectedWarehouse.WarehouseName}</p>
                        </div>
                        {selectedWarehouse.Location && (
                          <div className="col-span-2">
                            <label className="text-sm font-medium text-muted-foreground">Location</label>
                            <p className="text-sm">{selectedWarehouse.Location}</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Warehouse Configuration */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Configuration</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium text-muted-foreground">Status</label>
                          <div className="flex items-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${selectedWarehouse.Inactive === 'tNO' ? 'bg-green-500' : 'bg-red-500'}`}></div>
                            <span className={`text-sm ${getStatusColor(selectedWarehouse.Inactive || 'tNO')}`}>
                              {getStatusName(selectedWarehouse.Inactive || 'tNO')}
                            </span>
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-muted-foreground">Warehouse Type</label>
                          <div className="flex items-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${selectedWarehouse.DropShip === 'tYES' ? 'bg-blue-500' : 'bg-green-500'}`}></div>
                            <span className={`text-sm ${getDropShipColor(selectedWarehouse.DropShip || 'tNO')}`}>
                              {getDropShipName(selectedWarehouse.DropShip || 'tNO')}
                            </span>
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-muted-foreground">Nettable Status</label>
                          <div className="flex items-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${selectedWarehouse.Nettable === 'tYES' ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                            <span className={`text-sm ${getNettableColor(selectedWarehouse.Nettable || 'tNO')}`}>
                              {getNettableName(selectedWarehouse.Nettable || 'tNO')}
                            </span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground">
              <div className="text-center">
                <Warehouse className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>Select a warehouse to view details</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </SharedLayout>
  );
}